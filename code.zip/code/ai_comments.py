from openai import OpenAI
client = OpenAI(
     api_key = "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"
)

class ChatGPT:
     def __init__ (self,studentname,grade,strength,weakness,example):
          self.s = strength
          self.w = weakness
          self.e = example
          self.n = studentname
          self.g = grade

     def getComment (self):
          info = "In 75 words, write a comment about a student named " + self.n
          info += " in your English class and got a " + self.g + " grade. "
          info += "The student is good at " + self.s
          info += " and needs to work on " + self.w + "."
          info += " An example of the student's behavior in class would be " + self.e

          completion = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
              {"role": "user", "content": info}
            ]
          )

          return completion.choices[0].message.content
