class Report:
     def __init__ (self,filename):
          self.file = filename

     def getName (self,rollno):
          rollno -= 1
          
          f = open(self.file,"r")
          data = f.readlines()
          f.close()

          name = ''
          count = 0

          for i in range (0,len(data[rollno])):
               if data[rollno][i] == '~':
                    count += 1

               if count == 1:
                    break

               name += data[rollno][i]

          return name

     def getGrade (self,rollno):
          rollno -= 1
          
          f = open(self.file,"r")
          data = f.readlines()
          f.close()

          grade = ''
          count = 0

          for i in range (0,len(data[rollno])):
               if data[rollno][i] == '~':
                    count += 1

               if count == 1 and data[rollno][i] != '~' and data[rollno][i] != '\n':
                    grade += data[rollno][i]

          return grade

     def editReport (self,rollno,comment):
          rollno -= 1

          f = open(self.file,"r")
          data = f.readlines()
          f.close()

          var = data[rollno]
          data[rollno] = ''
          for i in range (0,len(var)-1):
               data[rollno] += var[i]

          data[rollno] += comment + "\n"

          f = open(self.file,"w")

          for j in range (0,len(data)):
               f.write(data[j])

          f.close()
