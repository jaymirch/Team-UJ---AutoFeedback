import check_report
import ai_comments

rollno = 1
start = "Y"

while start == "Y":
     report = check_report.Report("report.txt")

     name = report.getName(rollno)
     grade = report.getGrade(rollno)

     print("Student Name:",name," Grade:",grade)
     good = input("What is the student good at?: ")
     bad = input("What is the student bad at?: ")
     ex = input("What is the student's behavior like in your class?: ")

     chat = ai_comments.ChatGPT(name,grade,good,bad,ex)
     comment = chat.getComment()

     print(comment)

     newcomment = input("Would you like to generate a new comment? [Y/N]: ")
     while newcomment == "Y":
          comment = chat.getComment()
          print(comment)
          newcomment = input("Would you like to generate a new comment? [Y/N]: ")
          
     if newcomment == "N":
          report.editReport(rollno,comment)

     start = input("Would you like to report on the next student? [Y/N]: ")

     if start == "Y":
          rollno += 1
