import os
from openai import OpenAI

# Load API key from environment variable
api_key = os.environ.get("OPENAI_API_KEY")
print("API Key:", api_key)  # Print the API key value

if not api_key:
    raise ValueError("OPENAI_API_KEY environment variable is not set.")

# Initialize OpenAI client
client = OpenAI(api_key=api_key)

class Report:
    """Class to manage report file operations."""

    def __init__(self, filename):
        self.file = filename

    def read_data(self):
        """Read data from the report file."""
        try:
            with open(self.file, "r") as f:
                data = f.readlines()
        except FileNotFoundError:
            raise FileNotFoundError(f"File '{self.file}' not found.")
        return data

    def write_data(self, data):
        """Write data to the report file."""
        with open(self.file, "w") as f:
            f.writelines(data)

    def get_student_info(self, rollno):
        """Get name and grade of the student."""
        data = self.read_data()
        rollno -= 1
        try:
            name, grade = data[rollno].strip().split("~")
        except IndexError:
            raise IndexError("Invalid roll number.")
        return name, grade

    def update_report(self, rollno, comment):
        """Update the report with the student's comment."""
        data = self.read_data()
        rollno -= 1
        try:
            data[rollno] = f"{data[rollno].strip()} {comment}\n"
        except IndexError:
            raise IndexError("Invalid roll number.")
        self.write_data(data)

class ChatGPT:
    """Class to generate comments using OpenAI GPT-3."""

    def __init__(self, studentname, grade, strength, weakness, example):
        self.s = strength
        self.w = weakness
        self.e = example
        self.n = studentname
        self.g = grade

    def validate_grade(self, grade):
        """Validate the grade entered by the user."""
        valid_grades = ["A", "B", "C", "D", "F"]
        if grade.upper() not in valid_grades:
            raise ValueError("Invalid grade. Please enter a valid grade (A, B, C, D, F).")

    def get_comment(self):
        """Generate a comment using OpenAI GPT-3."""
        info = (
            f"In 75 words, write a comment about a student named {self.n} "
            f"in your English class who got a {self.g} grade. "
            f"The student is good at {self.s} and needs to work on {self.w}. "
            f"An example of the student's behavior in class would be {self.e}."
        )

        try:
            completion = client.chat.completions.create(
                model="text-davinci-003",
                messages=[{"role": "user", "content": info}],
            )
            return completion.choices[0].message.content
        except Exception as e:
            raise RuntimeError(f"Failed to generate comment: {str(e)}")

# Main program
if __name__ == "__main__":
    # Sample usage
    rollno = 1
    start = "Y"

    report = Report("report.txt")

    while start.upper() == "Y":
        try:
            name, grade = report.get_student_info(rollno)
            print(f"Student Name: {name}, Grade: {grade}")

            good = input("What is the student good at?: ")
            bad = input("What is the student bad at?: ")
            ex = input("State one example of the student's behavior in your class: ")

            chat = ChatGPT(name, grade, good, bad, ex)
            comment = chat.get_comment()

            print(comment)

            new_comment = input("Would you like to generate a new comment? [Y/N]: ")
            while new_comment.upper() == "Y":
                comment = chat.get_comment()
                print(comment)
                new_comment = input("Would you like to generate a new comment? [Y/N]: ")

            if new_comment.upper() == "N":
                report.update_report(rollno, comment)

            start = input("Would you like to report on the next student? [Y/N]: ")
            if start.upper() == "Y":
                rollno += 1
        except (FileNotFoundError, IndexError, ValueError, RuntimeError) as e:
            print(f"Error: {str(e)}")
